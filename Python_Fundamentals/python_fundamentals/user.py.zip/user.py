class User:
    def __init__(self, first_name, last_name, email, age):
        self.first_name = first_name
        self.last_name = last_name
        self.email = email
        self.age = age
        self.is_reward_member = False
        self.gold_card_point = 0
    #1
    def display_info(self):
        print(self.first_name, self.last_name, self.last_name, self.email, self.is_reward_member, self.gold_card_point)

    def enroll(self):
        self.is_reward_member = True
        if self.is_reward_member == True:
            self.gold_card_point = 200
        print(self.is_reward_member, self.gold_card_point)

    def spend_points(self,amount):
        if self.gold_card_point < amount:
            return 'you do not have enough'
        self.gold_card_point -= amount

#1
new_user= User('Hauvert', 'Pacheco', 'dojo@gmail.com', 48)

new_user.display_info()

#2
new_user.enroll()
new_user.display_info()